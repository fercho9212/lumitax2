<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DriversController extends Controller
{
    //
    public function CreateDriver(){
      echo "Holaaa Entroo aunque no creo";
    }
}
