<!DOCTYPE html>
<html>

@include('panel.layouts.partials.head')

@yield('content')

</html>
