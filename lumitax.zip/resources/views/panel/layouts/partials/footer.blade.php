<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <div class="pull-right hidden-xs">
        <a href="https://github.com/acacha/adminlte-laravel"></a><b>Fercho9212</b></a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; Lumitax 2015 <a href="http://acacha.org">wwww.lumitax.com.co</a>.</strong> {{ trans('adminlte_lang::message.createdby') }} <a href="http://acacha.org/sergitur">Treesign</a>.  <a href="https://github.com/fercho9212">Github</a>
</footer>
