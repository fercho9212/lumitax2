<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->

    <section class="sidebar">

        <!-- Sidebar user panel (optional) -->
        @yield('menu')
        
    </section>
    <!-- /.sidebar -->
</aside>
