@extends('panel.modules.vehicle.ActionVehicle.layout')
@section('contenido_principal')
    @include('panel.modules.vehicle.ActionVehicle.view.view')
@endsection
