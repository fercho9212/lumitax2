@extends('panel.modules.vehicle.ActionVehicle.dashboard')
@section('contenido_principal')
    @include('panel.modules.vehicle.ActionVehicle.view.view')
@endsection
