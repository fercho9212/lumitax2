


<?php $__env->startSection('style'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('/complement/repairsweet/sweet-alert.css')); ?>" >
	<link rel="stylesheet" href="<?php echo e(asset('/complement/datetimepicker/bootstrap-datetimepicker.min.css')); ?>" >
	<link rel="stylesheet" href="<?php echo e(asset('/complement/bootstrap-select/bootstrap-select.min.css')); ?>">
  <link rel="stylesheet" href="https://rawgit.com/enyo/dropzone/master/dist/dropzone.css">
	<link type="text/css" href="//gyrocode.github.io/jquery-datatables-checkboxes/1.2.9/css/dataTables.checkboxes.css" rel="stylesheet" />

	
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" type="text/css"/>
	<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.4.0/css/buttons.dataTables.min.css" type="text/css"/>

	
	<link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" type="text/css"/>
	<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css" type="text/css"/>




 <?php $__env->stopSection(); ?>

<?php $__env->startSection('panel.htmlheader_title'); ?>
	Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('menu'); ?>
	<?php echo $__env->make('panel.modules.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
	<!--<div class="container spark-screen">-->
		<div class="row">
			<div class="col-md-12">
				<div class="panel  panel-primary">
					<div class="panel-heading"><center>LUMITAX</center></div>
					<div class="panel-body">
						<div id="contenido_principal">
                <div class="da">
                  dsadasdasd
                </div>
								<?php echo $__env->make('panel.modules.vehicle.ActionVehicle.view.view', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

						</div>
						<!-- load-->
										<div style="display: none" id="cargador_empresa" align="center">
											<br><br><br><br>
													 	<center><img src="img/cargando.gif" align="middle" alt="cargador"> &nbsp;</center>
														<center><label style="color:#ABB6BA">Realizando tarea solicitada ...</label></center>
														<br><br>
													 <hr style="color:#003" width="50%">
													 <br>
									 </div>
						<!-- end load-->
					</div>
				</div>
			</div>
		</div>
	<!--</div>-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts_table'); ?>
<?php echo $__env->make('panel.layouts.partials.script_for_table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script type="text/javascript" src="<?php echo e(asset('/complement/repairsweet/sweet-alert.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/complement/bootstrap-validator/validator.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/complement/moment/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/complement/datetimepicker/bootstrap-datetimepicker.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/complement/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
		
<script src="https://rawgit.com/enyo/dropzone/master/dist/dropzone.js"></script>

		
<script type="text/javascript" src="<?php echo e(asset('/complement/bootstrap-checkbox/bootstrap-checkbox.min.js')); ?>"></script>
		

<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>