
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
       <div class="alert alert-danger" role="alert">
        <center><strong>Warning!</strong>  <?php echo e($error); ?></center>
       </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>



<center>
           <button type="button" class="col-md-offset-11 btn btn-success  btn-circle-large" data-toggle="modal" data-target="#frmpassenger" id="addpassenger" >
             <span class="glyphicon glyphicon glyphicon-plus"> </span>
          </button>
</center>
<br>


<?php echo $__env->make('panel.modules.passenger.modals.create', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('panel.modules.passenger.modals.edit', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div class="table-responsive text-center">
  <div class="table-responsive text-center">
      <table class="table table-borderless" id="table">
          <thead>
              <tr>
                  <th class="text-center">Nombre</th>
                  <th class="text-center">Apellaido</th>
                  <th class="text-center">Email</th>
                  <th class="text-center">Tel:Movíl</th>
                  <th class="text-center">Estado</th>
                  <th class="text-center">Acción</th>
                  <th class="text-center">Registrado el</th>
              </tr>
          </thead>
          <?php $__currentLoopData = $passengers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passenger): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>


                  <tr class="driver<?php echo e($passenger->id); ?>">
                  <td><?php echo e($passenger->pas_name); ?></td>
                  <td><?php echo e($passenger->pas_last); ?></td>
                  <td><?php echo e($passenger->email); ?></td>
                  <td><?php echo e($passenger->pas_movil); ?></td>
                  <td><?php echo e($passenger->state->state); ?></td>
                  <td><?php echo e($passenger->created_at); ?></td>
                  <td>
                        <button  class="update btn btn-info btn-circle-medium" data-id="<?php echo e($passenger->id); ?>"
                                          data-name="<?php echo e($passenger->pas_name); ?>"
                                          data-last="<?php echo e($passenger->pas_last); ?>"
                                          data-email="<?php echo e($passenger->email); ?>"
                                          data-movil="<?php echo e($passenger->pas_movil); ?>"
                                          data-state="<?php echo e($passenger->state->id); ?>"
                                          data-date="<?php echo e($passenger->created_at); ?>"
                            data-toggle="modal" data-target="#edit_passenger" >
                            <span class="glyphicon glyphicon-edit"></span>
                        </button>
                        <button   class="btn-circle-medium btn btn-danger" data-toggle="modal"  data-target="#dataDelete" onclick="delete_passenger(<?php echo e($passenger->id); ?>)">
                            <span class="glyphicon glyphicon-trash"></span>
                        </button>
                    </td>
                  </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </table>
    </div>

<script>
  $('#table').dataTable();
 function delete_passenger(id){
   var urlDelte='/passengers/'+id;
   var token=$('input[name=_token]').val();
   var urlSuccess='/passengers';
   swal({
         title: "Estas seguro?",
         text: "Desea Eliminar el Seguro!",
         type: "warning",
         showCancelButton: true,
         confirmButtonColor: "#DD6B55",
         confirmButtonText: "Si, Eliminar!",
         closeOnConfirm: false
 },
 function(){
   deleteNormal(urlDelte,token,urlSuccess);
 });
 }
  //Inicializa la tabla

//Function in tiemp real
/*
$(document).ready(function(){

setTimeout(data(),2000);
});
*/



  /*var otable=$('#table').DataTable();
  otable.ajax.reload();*/
  //Inicializa el modal registar
  $('#frmpassenger').on("shown.bs.modal", function () {
        $("body").removeClass("modal-open");
        $("body").css({"padding-right":"0px"});
  });
  //Funcíon al salir del modal
  $('#frmpassenger').on('hidden.bs.modal', function (e) {
        $("#frmpassenger").removeClass("modal-open");
  });
  //Eliminar modal


  $('#confirm-delete').on('show.bs.modal', function(e) {
    $(this).find('.danger').attr('data-id', $(e.relatedTarget).data('id'));
});

$('#dataDelete').on('show.bs.modal', function (event) {
  var button = $(event.relatedTarget) // Botón que activó el modal
  var id = button.data('id') // Extraer la información de atributos de datos
  var modal = $(this)
  modal.find('#del').attr('data-id', id);
})

$('#del').on('click', function(e){
  e.preventDefault();
  var id = $('#del').data('id');
  alert(id);
});
/**
  $(document).on('click', '#delete', function() {
        var id=$(this).data('id');


        $.ajax({
                  type: 'DELETE',
                  url: '/passengers/'+id,
                  data: {
                      '_token': $('input[name=_token]').val(),
                  },
                  success: function(data) {
                          swal("Deleted!", "Registro Eliminado.", "success");
                          loadData('/passengers/',data);
                        //  $('#table').find('.driver'+id).remove();
                  }
              });

  });
//Editar
**/
  function edit_passenger(id){
    var idd=id;
    var url='/passengers/'+idd+'/edit'
    $.ajax({
              type: 'GET',
              url: url,
              beforeSend:function(){
                        $("#contenido_principal").html($("#cargador_empresa").html());
              },
              complete:function(){

              },
              success: function(data) {

                        $("#contenido_principal").html(data);
              }
          })
  }
</script>
