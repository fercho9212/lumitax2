<div class="table-responsive text-center">
    <table class="table table-borderless" id="table">
        <thead>
            <tr>
                <th class="text-center">Placa</th>
                <th class="text-center">Servicio</th>
                <th class="text-center">Modelo</th>
                <th class="text-center">Motor</th>
                <th class="text-center">Serie</th>
                <th class="text-center">Vin</th>
                <th class="text-center">Color</th>
                <th class="text-center">Tipo</th>
                <th class="text-center">Clase</th>
                <th class="text-center">Marca</th>
                <th class="text-center">Documentos</th>
            </tr>
        </thead>
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>


                <tr class="driver<?php echo e($vehicle->id); ?>">
                <td><?php echo e($vehicle->placa); ?></td>
                <td><?php
                  if ($vehicle->leveles_id=='1') {
                    echo 'Taxi';
                  }elseif ($vehicle->leveles_id=='2') {
                    echo 'Lujo';
                  }elseif ($vehicle->leveles_id=='3') {
                    echo "Premium";
                  }
                ?></td>

                <td><?php echo e($vehicle->veh_model); ?></td>
                <td><?php echo e($vehicle->veh_motor); ?></td>
                <td><?php echo e($vehicle->veh_serie); ?></td>
                <td><?php echo e($vehicle->veh_vin); ?></td>
                <td><?php echo e($vehicle->veh_color); ?></td>
                <td><?php echo e($vehicle->typevehicle->type); ?></td>
                <td><?php echo e($vehicle->classvehicle->class); ?></td>
                <td><?php echo e($vehicle->brandvehicle->brand); ?></td>
              
                  <td>
                    <a href="/vehicles/<?php echo e($vehicle->id); ?>/show">
                    <button   class="update btn btn-warning">
                        <span class="glyphicon glyphicon-edit"></span>
                    </button>
                    </a>

                    <button class="delete-modal btn btn-danger" href="javascript:void(0);" data-id="<?php echo e($vehicle->id); ?>"
                        data-name="<?php echo e($vehicle->dri_name); ?>">
                        <span class="glyphicon glyphicon-trash"></span>
                    </button>


                  

                  </td>
                </tr>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>
</div>


  <script type="text/javascript">
    $('#table').DataTable();
    function add_document(id){
      url='/documents/'+id;
      $.ajax({
        type:'GET',
        url:url,
        success:function(data){
          loadData(url,data);
        },
    });
    }
    $(document).on('click', '.delete-modal', function() {


          var id=$(this).data('id');

          swal({
                title: "Estas seguro?",
                text: "Desea Eliminar el Conductor!",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "Si, Eliminar!",
                closeOnConfirm: false
        },
        function(){
              var urlDelete= '/vehicles/'+id;
              var token=$('input[name=_token]').val();
              var urlView='/vehicles/';
              deleteNormal(urlDelete,token,urlView);
            });
    });

    function edit(id){
      var url='/vehicles/'+id+'/edit'
      var token=$('input[name=_token]').val();
      ajaxEdit(id,url,token);
    }
    function action(id){
      var url=""+id+"/show";
      $.ajax({
        type:'GET',
        url:url,
        success:function(data){
          console.log(data);
        }
      });

      }




  </script>
