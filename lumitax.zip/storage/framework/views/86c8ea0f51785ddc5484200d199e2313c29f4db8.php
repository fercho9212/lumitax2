
<?php $__env->startSection('contenido_principal'); ?>
    <?php echo $__env->make('panel.modules.vehicle.ActionVehicle.view.view', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.modules.vehicle.ActionVehicle.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>