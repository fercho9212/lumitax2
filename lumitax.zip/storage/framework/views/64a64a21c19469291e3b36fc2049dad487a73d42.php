<?php if(! Auth::guest()): ?>
    <div class="user-panel">
        <div class="pull-left image">
            <img src="<?php echo e(asset('/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image" />
        </div>
        <div class="pull-left info">
            <p><?php echo e(Auth::user()->name); ?></p>
            <!-- Status -->
            <a href="#"><i class="fa fa-circle text-success"></i>Panel</a>
        </div>
    </div>
<?php endif; ?>

<!-- search form (Optional) -->

<!-- /.search form -->

<!-- Sidebar Menu -->
<ul class="sidebar-menu">
    <li class="header"><center>ADMINISTRACIÓN</center></li>
    <!-- Optionally, you can add icons to the links -->


    <li class="treeview">
        <a href="#"><i class='fa fa-link'></i> <span>Conductores</span> <i class="fa fa-angle-left pull-right"></i></a>
        <ul class="treeview-menu">
            <li class="active"><a href="javascript:void(0);" onclick="load_frm(1);">Crear</a></li>
            <li ><a href="javascript:void(0);" onclick="load_frm(2);">Ver</a></li>
        </ul>
    </li>
    <li><a href="javascript:void(0);" onclick="load_frm(10);"><i class='fa fa-link'></i> <span>Usuarios</span></a></li>
    <li><a href="javascript:void(0);" onclick="load_frm(20);"><i class='fa fa-link'></i> <span>Asignación</span></a></li>
    <li class="treeview">
        <a href="#"><i class='fa fa-link'></i> <span>Vehículos</span> <i class="fa fa-angle-left pull-right"></i></a>
        <ul class="treeview-menu">
            <li><a href="javascript:void(0);"  onclick="load_frm(32);">Crear</a></li>
            <li><a href="javascript:void(0);"  onclick="load_frm(30);">Vehículos Taxi</a></li>
            <li><a href="javascript:void(0);"  onclick="load_frm(31);">Vehículos Lujo</a></li>
            <li><a href="javascript:void(0);"  onclick="load_frm(33);">Vehículos Premium</a></li>
        </ul>
    </li>

    <li><a href="javascript:void(0);" onclick="load_frm(40);"><i class='fa fa-link'></i> <span>Seguros</span></a></li>
    <li><a href="javascript:void(0);" onclick="load_frm(50);"><i class='fa fa-link'></i> <span>Historial</span></a></li>


</ul><!-- /.sidebar-menu -->
