
<?php $__env->startSection('style'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('/complement/repairsweet/sweet-alert.css')); ?>" href="/css/master.css">
  <link rel="stylesheet" href="<?php echo e(asset('/complement/datetimepicker/bootstrap-datetimepicker.min.css')); ?>" >
  <link rel="stylesheet" href="<?php echo e(asset('/complement/bootstrap-select/bootstrap-select.min.css')); ?>">

  <link rel="stylesheet" href="https://rawgit.com/enyo/dropzone/master/dist/dropzone.css">

  <link rel="stylesheet" href="<?php echo e(asset('/complement/lightbox2/lightbox.min.css')); ?>">



  <style>
  .skin-blue .wrapper, .skin-blue .main-sidebar, .skin-blue .left-side {
      background-color: #3E2723 !important;
  }
  .skin-red .wrapper, .skin-red .main-sidebar, .skin-red .left-side {
      background-color: #000000 !important;
}
  </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('theme-body'); ?>
  <link href="<?php echo e(asset('/css/skins/skin-red.css')); ?>" rel="stylesheet" type="text/css" />
  <body class="skin-red sidebar-mini">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('panel.htmlheader_title'); ?>
	Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('menu'); ?>
	<?php if(! Auth::guest()): ?>
	    <div class="user-panel">
	        <div class="pull-left image">
	            <img src="<?php echo e(asset('/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image" />
	        </div>
	        <div class="pull-left info">
	            <p><?php echo e($vehicle->placa); ?></p>
	            <!-- Status
	            <a href="#"><i class="fa fa-circle text-success"></i>Panel</a>-->
	        </div>
	    </div>
	<?php endif; ?>

	<!-- Sidebar Menu -->
	<ul class="sidebar-menu">
	    <li class="header"><center>ADMINISTRACIÓN</center></li>
	    <!-- Optionally, you can add icons to the links -->

      <li><a href="/vehicles/<?php echo e($vehicle->id); ?>/show" ><i class='fa fa-link'></i> <span>Ver</span></a></li>
      <li><a href="javascript:void(0);" onclick="ActionDocument(4,<?php echo e($vehicle->id); ?>);"><i class='fa fa-link'></i> <span>Editar</span></a></li>
	    <li><a href="javascript:void(0);" onclick="ActionDocument(2,<?php echo e($vehicle->id); ?>);"><i class='fa fa-link'></i> <span>Agregar Docuemntos</span></a></li>
      <li><a href="javascript:void(0);" onclick="ActionDocument(3,<?php echo e($vehicle->id); ?>);"><i class='fa fa-link'></i> <span>Agregar Fotos</span></a></li>

	</ul><!-- /.sidebar-menu -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
	<!--<div class="container spark-screen">-->
		<div class="row">
			<div class="col-md-12">
				<div class="panel  panel-primary" >
					<div class="panel-heading" style="background-color: #000000"><center>MODULO DE VEHICULOS</center></div>
					<div class="panel-body">
						<div id="contenido_principal">
							<?php echo $__env->yieldContent('contenido_principal'); ?>
						</div>
						<!-- load-->
										<div style="display: none" id="cargador_empresa" align="center">
											<br><br><br><br>
													 	<center><img src="/img/cargando.gif" align="middle" alt="cargador"> &nbsp;</center>
														<center><label style="color:#ABB6BA">Realizando tarea solicitada ...</label></center>
														<br><br>
													 <hr style="color:#003" width="50%">
													 <br>
									 </div>
						<!-- end load-->
					</div>
				</div>
			</div>
		</div>
	<!--</div>-->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts_table'); ?>
<?php echo $__env->make('panel.layouts.partials.script_for_table', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript" src="<?php echo e(asset('/complement/repairsweet/sweet-alert.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/complement/bootstrap-validator/validator.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/complement/moment/moment.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/complement/datetimepicker/bootstrap-datetimepicker.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('/complement/bootstrap-select/bootstrap-select.min.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('/complement/bootstrap-checkbox/bootstrap-checkbox.min.js')); ?>"></script>

<script src="https://rawgit.com/enyo/dropzone/master/dist/dropzone.js"></script>

<script type="text/javascript" src="<?php echo e(asset('/complement/lightbox2/lightbox.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.dashboard', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>