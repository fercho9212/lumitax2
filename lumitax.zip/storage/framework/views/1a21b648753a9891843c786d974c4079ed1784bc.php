<style>

</style>

<div class="panel panel-default">
  <div class="panel-heading col-black"><center>Datos del vehiculo</center></div>
  <br><br>


    <div class="panel-body">
      <div class="col-md-8  col-md-offset-2">
        <div class="row">
          <strong>DATOS BASICOS</strong>
      <table class="table table-bordered" >


        <tbody>
        <tr>
          <td class="col-black">Placa:</td>
          <td><?php echo e($vehicle->placa); ?></td>
          <td class="col-black">Modelo</td>
          <td><?php echo e($vehicle->veh_model); ?></td>
        </tr>
        <tr>
          <td class="col-black">Color</td>
          <td><?php echo e($vehicle->veh_color); ?></td>
          <td class="col-black">Clase</td>
          <td><?php echo e($vehicle->classvehicle->class); ?></td>
        </tr>
        <tr>
          <td class="col-black">Marca</td>
          <td><?php echo e($vehicle->brandvehicle->brand); ?></td>
          <td class="col-black">Tipo</td>
          <td><?php echo e($vehicle->leveles_id); ?></td>
        </tr>
        <tr>
          <td class="col-black">motor</td>
          <td><?php echo e($vehicle->veh_motor); ?></td>
          <td class="col-black">Serie</td>
          <td><?php echo e($vehicle->veh_serie); ?></td>
        </tr>
        <tr>
          <td class="col-black">Vin</td>
          <td><?php echo e($vehicle->veh_vin); ?></td>
          <td class="col-black">Creado</td>
          <td><?php echo e($vehicle->created_at); ?></td>
        </tr>
      </tbody>
      </table>
  </div>

</div>
<?php if($vehicle->leveles_id=='2' or $vehicle->leveles_id=='3'): ?>
    <div class="col-md-10  col-md-offset-1">
      <div class="row">
            <br>
            <center><strong>DATOS SERVICIO LUJO</strong><center>
              <br>
                <table class="table table-bordered" >

                  <tbody>
                      <tr>
                        <td class="col-black">Frenos</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_brakes); ?></td>
                        <td class="col-black">Bolsas de aire</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_Airbags); ?></td>

                        <td class="col-black">Cabecera</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_head); ?></td>
                        <td class="col-black">Puertas</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_doors); ?></td>
                      </tr>
                      <tr>
                        <td class="col-black">Cabina</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_cabin); ?></td>
                        <td class="col-black">Cant Pasajeros</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_passagers); ?></td>

                        <td class="col-black">Espacio</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_space); ?></td>
                        <td class="col-black">Sillateria</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_sillateria); ?></td>
                      </tr>
                      <tr>
                        <td class="col-black">Bodega</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_cellar); ?></td>
                        <td class="col-black">Cilindraje</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_cylinder); ?></td>

                        <td class="col-black">Potencia</td>
                        <td><?php echo e($vehicle->vehiclecomplement->vc_power); ?></td>
                        <td class="col-black">Tipo de carroceria</td>
                        <td><?php echo e($vehicle->vehiclecomplement->typebodywork->bodywork); ?></td>
                      </tr>
              </tbody>
             </table>
           </div>
         </div>
              <?php endif; ?>

    </div>


</div>
